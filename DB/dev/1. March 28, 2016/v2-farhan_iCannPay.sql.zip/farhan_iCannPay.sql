-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2016 at 10:30 AM
-- Server version: 5.5.42-37.1
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `farhan_iCannPay`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(11) NOT NULL,
  `store_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '1',
  `updated` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `store_id`, `user_id`, `name`, `parent_id`, `status`, `updated`, `created`) VALUES
(1, 1, 2, 'fashionssss', 0, 1, '2016-03-13 15:16:08', '2016-03-13 15:13:48'),
(2, 123, 3, 'test category', 0, 1, '2016-03-17 04:31:22', '2016-03-17 04:31:22'),
(3, 14, 18, 'Test Umair Category - Changed', 0, 1, '2016-03-24 11:03:17', '2016-03-24 10:59:20'),
(4, 14, 18, 'Test Umair Sub-Category', 3, 1, '2016-03-24 11:00:35', '2016-03-24 11:00:35');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE IF NOT EXISTS `devices` (
  `device_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `uid` varchar(255) DEFAULT NULL,
  `type` tinyint(1) DEFAULT NULL COMMENT '0=iphone,1=android',
  `os_version` varchar(100) DEFAULT NULL,
  `lang` tinyint(1) DEFAULT '0' COMMENT '0=en,1=ar',
  `token` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`device_id`, `user_id`, `uid`, `type`, `os_version`, `lang`, `token`) VALUES
(1, 2, 'asdfasd', 1, NULL, 0, 'bc035a9475c2757698b6ffd289c12cc8'),
(3, 2, 'asdfasd', 1, NULL, 0, 'bc035a9475c2757698b6ffd289c12cc8'),
(5, 3, '0987654321', 0, '9.1', 0, 'af35493adcabc550136ff2cd34ce6d1d'),
(6, 4, '1234', 0, NULL, 0, 'cb66d0b23251c71cad7090efba9c7742'),
(7, 4, '1234', 0, NULL, 0, 'cb66d0b23251c71cad7090efba9c7742'),
(8, 5, '11211', 0, NULL, 0, NULL),
(9, 6, '11211', 0, NULL, 0, NULL),
(10, 7, '11211', 0, NULL, 0, NULL),
(11, 7, '1234', 0, NULL, 0, '40432ed2f995eb5619b4006180886c47'),
(12, 8, '11211', 0, NULL, 0, NULL),
(13, 8, '1234', 0, NULL, 0, 'd693a15e9fddaa45ab1160ad233296cd'),
(14, 9, '11211', 0, NULL, 0, NULL),
(15, 9, '1234', 0, NULL, 0, '768e79972de13fbfb8eff3575129cb80'),
(16, 10, '1234', 0, NULL, 0, 'e5e70d2ad16fe7f55227dcfc2c900f60'),
(17, 10, '1234', 0, NULL, 0, 'e5e70d2ad16fe7f55227dcfc2c900f60'),
(18, 11, '11211', 0, NULL, 0, NULL),
(19, 11, '1234', 0, NULL, 0, 'a673bff23091c071a789e040179dbd00'),
(20, 12, '11211', 0, NULL, 0, NULL),
(21, 12, '1234', 0, NULL, 0, '952d1cec84fec8b9a70cf686296ef9d7'),
(22, 13, '11211', 0, NULL, 0, NULL),
(23, 13, '1234', 0, NULL, 0, '655286883b1c5857577189e10a74707b'),
(24, 14, '11211', 0, NULL, 0, NULL),
(25, 14, '1234', 0, NULL, 0, 'c22fb8022679eee4ccb2f7feada0ab92'),
(26, 15, '11211', 0, NULL, 0, NULL),
(27, 15, '1234', 0, NULL, 0, '6938c007e1a2e58c50b7382b6d33d1ef'),
(28, 16, '11211', 0, NULL, 0, NULL),
(29, 16, '1234', 0, NULL, 0, '061e2440ba9b69d3495a514adb1ac383'),
(31, 17, '123', 1, NULL, 0, 'b7bd2bc3edddbb2af9b06a228fd3b657'),
(32, 18, '0987654321', 0, '9.2', 0, '8446fa4f07320b96cd87f7a25dfe880d');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `log_id` int(11) NOT NULL,
  `store_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `action_type` varchar(100) DEFAULT NULL COMMENT 'e.g. ''order''',
  `action_id` int(11) DEFAULT '0' COMMENT 'e.g. ''order_id''',
  `log_details` text COMMENT 'user_login, user_logout, order placed, order paid, invoice-sent-to-customer',
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL,
  `store_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '0' COMMENT '1=general, 2=numeric_pad',
  `total_amount` double(10,2) DEFAULT '0.00',
  `description` text,
  `customer_signature` varchar(100) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `receipt` varchar(100) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0' COMMENT '1=paid, 2=split_paid, 3=refunded, 4=split_refunded, 5=fail, 6=pending',
  `created` datetime DEFAULT NULL,
  `total_refund` double(10,2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `store_id`, `user_id`, `type`, `total_amount`, `description`, `customer_signature`, `customer_email`, `receipt`, `status`, `created`, `total_refund`) VALUES
(5, 14, 18, 0, 450.00, '', NULL, 'fbashir@technyx.com', NULL, 0, '2016-03-24 11:51:24', 0.00),
(6, 14, 18, 0, 851.00, '', NULL, 'umair@technyx.com', NULL, 0, '2016-03-24 11:53:15', 0.00),
(7, 14, 18, 0, 851.00, '', NULL, 'umair@technyx.com', NULL, 0, '2016-03-24 11:57:29', 0.00),
(8, 14, 18, 0, 851.00, '', NULL, 'umair@technyx.com', NULL, 0, '2016-03-24 11:58:47', 0.00),
(9, 14, 18, 0, 851.00, '', NULL, 'umair@technyx.com', NULL, 0, '2016-03-24 11:59:41', 0.00),
(10, 14, 18, 0, 670.00, '', NULL, 'umair@technyx.com', NULL, 0, '2016-03-24 11:59:56', 181.00),
(11, 14, 18, 0, 1600.00, '', NULL, 'umair@technyx.com', NULL, 0, '2016-03-24 12:51:15', 0.00),
(12, 14, 18, 0, 1600.00, '', NULL, 'umair@technyx.com', NULL, 0, '2016-03-24 12:51:39', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_line_items`
--

CREATE TABLE IF NOT EXISTS `order_line_items` (
  `order_line_item_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT '0',
  `product_id` int(11) DEFAULT '0',
  `quantity` int(11) DEFAULT '0',
  `product_price` double(10,2) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `order_line_items`
--

INSERT INTO `order_line_items` (`order_line_item_id`, `order_id`, `product_id`, `quantity`, `product_price`, `status`, `created`) VALUES
(5, 5, 1, 2, 217.00, 0, '2016-03-24 11:51:24'),
(6, 5, 1, 2, 217.00, 0, '2016-03-24 11:51:24'),
(7, 6, 1, 3, 217.00, 0, '2016-03-24 11:53:15'),
(8, 7, 1, 3, 217.00, 0, '2016-03-24 11:57:29'),
(9, 7, -1, 1, 200.00, 0, '2016-03-24 11:57:29'),
(10, 8, 1, 3, 217.00, 0, '2016-03-24 11:58:47'),
(11, 8, -1, 1, 200.00, 0, '2016-03-24 11:58:47'),
(12, 9, 1, 3, 217.00, 0, '2016-03-24 11:59:41'),
(13, 9, -1, 1, 200.00, 0, '2016-03-24 11:59:41'),
(14, 10, 1, 3, 217.00, 0, '2016-03-24 11:59:56'),
(15, 10, -1, 1, 200.00, 0, '2016-03-24 11:59:56'),
(16, 11, 1, 2, 217.00, 0, '2016-03-24 12:51:15'),
(17, 11, 3, 3, NULL, 0, '2016-03-24 12:51:15'),
(18, 11, -1, 1, 200.00, 0, '2016-03-24 12:51:15'),
(19, 12, 1, 2, 217.00, 0, '2016-03-24 12:51:39'),
(20, 12, -1, 1, 200.00, 0, '2016-03-24 12:51:39');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  `description` text,
  `price` double(10,2) DEFAULT '0.00',
  `status` tinyint(4) DEFAULT '1',
  `updated` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `store_id`, `user_id`, `name`, `description`, `price`, `status`, `updated`, `created`) VALUES
(-1, 0, 0, 'Numeric Pad', NULL, 0.00, 1, NULL, NULL),
(1, 14, 18, 'Test Umair Product - Changed', 'Test Umair Product Description2', 217.00, 1, '2016-03-24 11:10:28', '2016-03-24 11:08:03');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE IF NOT EXISTS `product_categories` (
  `product_category_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT '0',
  `category_id` int(11) DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`product_category_id`, `product_id`, `category_id`) VALUES
(3, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `product_media`
--

CREATE TABLE IF NOT EXISTS `product_media` (
  `media_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT '0',
  `file_name` varchar(100) DEFAULT NULL,
  `media_type` varchar(100) DEFAULT NULL COMMENT '''image'' for now',
  `status` tinyint(4) DEFAULT '1',
  `updated` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `role_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `name`) VALUES
(1, 'Super Admin'),
(2, 'Business Admin'),
(3, 'Business Staff');

-- --------------------------------------------------------

--
-- Table structure for table `security_questions`
--

CREATE TABLE IF NOT EXISTS `security_questions` (
  `question_id` int(11) NOT NULL,
  `question` varchar(200) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `security_questions`
--

INSERT INTO `security_questions` (`question_id`, `question`, `last_updated`) VALUES
(1, 'what is the name of your favorite animal?', '2016-03-07 00:00:00'),
(2, 'what is the name of your favorite place?', '2016-03-07 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
  `transaction_id` int(11) NOT NULL,
  `store_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0' COMMENT '1=payment, 2=refund',
  `amount_cc` double(10,2) DEFAULT NULL,
  `amount_cash` double(10,2) DEFAULT NULL,
  `is_cc_swipe` tinyint(4) DEFAULT '0',
  `cc_name` varchar(100) DEFAULT NULL,
  `cc_number` varchar(100) DEFAULT NULL,
  `cc_expiry_year` int(11) DEFAULT '0',
  `cc_expiry_month` int(11) DEFAULT '0',
  `auth_code` varchar(100) DEFAULT NULL COMMENT 'also store ALL the confirmation details sent by cardXecure API',
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `store_id`, `user_id`, `order_id`, `type`, `amount_cc`, `amount_cash`, `is_cc_swipe`, `cc_name`, `cc_number`, `cc_expiry_year`, `cc_expiry_month`, `auth_code`, `created`) VALUES
(5, 14, 18, 5, 1, 225.00, 225.00, 0, NULL, NULL, 0, 0, NULL, '2016-03-24 11:51:24'),
(6, 14, 18, 6, 1, 551.00, 300.00, 0, NULL, NULL, 0, 0, NULL, '2016-03-24 11:53:15'),
(7, 14, 18, 7, 1, 551.00, 300.00, 0, NULL, NULL, 0, 0, NULL, '2016-03-24 11:57:29'),
(8, 14, 18, 8, 1, 0.00, 851.00, 0, NULL, NULL, 0, 0, NULL, '2016-03-24 11:58:47'),
(9, 14, 18, 9, 1, 0.00, 851.00, 0, NULL, NULL, 0, 0, NULL, '2016-03-24 11:59:41'),
(10, 14, 18, 10, 1, 0.00, 851.00, 0, NULL, NULL, 0, 0, NULL, '2016-03-24 11:59:56'),
(11, 14, 18, 10, 2, NULL, 170.00, 0, NULL, NULL, 0, 0, NULL, '2016-03-24 12:32:05'),
(12, 14, 18, 10, 2, 11.00, 0.00, 0, NULL, NULL, 0, 0, NULL, '2016-03-24 12:34:36'),
(13, 14, 18, 11, 1, 1300.00, 300.00, 0, 'Umair', 'XXXX-XXXX-XXXX-5678', 2016, 12, NULL, '2016-03-24 12:51:15'),
(14, 14, 18, 12, 1, 1300.00, 300.00, 0, 'Umair', 'XXXX-XXXX-XXXX-5678', 2016, 12, NULL, '2016-03-24 12:51:39');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL,
  `parent_user_id` int(11) DEFAULT '0' COMMENT 'If user role is ''Staff'' then, this field will have user_id of ''Business Admin''',
  `first_name` varchar(200) DEFAULT NULL,
  `last_name` varchar(250) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `plain_password` varchar(250) DEFAULT NULL,
  `role_id` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '1',
  `updated` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `new_password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `parent_user_id`, `first_name`, `last_name`, `email`, `password`, `plain_password`, `role_id`, `status`, `updated`, `created`, `new_password`) VALUES
(1, 0, 'iCannPay Admin', NULL, 'admin@icannpay.com', 'd97efba289c7b62681731b0bd1ce4ae9', NULL, 1, 1, '2016-03-07 00:00:00', '2016-03-07 00:00:00', NULL),
(2, 0, 'farhan', NULL, 'fbashir@folio3.com', 'd97efba289c7b62681731b0bd1ce4ae9', NULL, 2, 1, '2016-03-13 14:53:01', '2016-03-13 14:53:01', NULL),
(3, 0, 'Umair', NULL, 'umair.jaffar97@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, 2, 1, '2016-03-17 03:45:58', '2016-03-17 03:45:58', NULL),
(4, 0, 'Wasif', NULL, 'wasif@mailinator.com', '25d55ad283aa400af464c76d713c07ad', NULL, 2, 1, '2016-03-20 08:00:40', '2016-03-20 08:00:40', NULL),
(5, 0, 'was', NULL, 'was@mailinator.com', '225f667d9243201a6b2b35e008ebe3d3', NULL, 2, 1, '2016-03-20 13:20:57', '2016-03-20 13:20:57', NULL),
(6, 0, 'vvvv', NULL, 'ee@dff.com', '73e4c090131b3654bf1820997506f8e0', NULL, 2, 1, '2016-03-20 13:22:43', '2016-03-20 13:22:43', NULL),
(7, 0, 'bbjj', NULL, 'vvnk@ttyh.com', 'd6d56e20666d74e414c52c82e6cbadce', NULL, 2, 1, '2016-03-20 13:30:24', '2016-03-20 13:30:24', NULL),
(8, 0, 'Syed Sami', NULL, 'ahbab@technyxsystems.com', 'de0d92e7106dfa75956821950b59b579', NULL, 2, 1, '2016-03-21 05:36:06', '2016-03-21 05:36:06', NULL),
(9, 0, 'Wasif', NULL, 'wasif123@mailinator.com', '22d7fe8c185003c98f97e5d6ced420c7', NULL, 2, 1, '2016-03-24 02:34:26', '2016-03-24 02:34:26', NULL),
(10, 0, 'Wasif Iqbal', NULL, 'waz@mailinator.com', '22d7fe8c185003c98f97e5d6ced420c7', NULL, 2, 1, '2016-03-24 02:50:51', '2016-03-24 02:50:51', NULL),
(11, 0, 'asda', NULL, 'asd@mailinator.com', '22d7fe8c185003c98f97e5d6ced420c7', NULL, 2, 1, '2016-03-24 02:53:27', '2016-03-24 02:53:27', NULL),
(12, 0, 'Testing', NULL, 'asd123@mailinator.com', '22d7fe8c185003c98f97e5d6ced420c7', NULL, 2, 1, '2016-03-24 02:54:35', '2016-03-24 02:54:35', NULL),
(13, 0, '123', NULL, '123@m.com', '22d7fe8c185003c98f97e5d6ced420c7', NULL, 2, 1, '2016-03-24 03:20:55', '2016-03-24 03:20:55', NULL),
(14, 0, 'asda', NULL, 'asdasd@asda.com', '4ec5c16af0784c409e4752cb8fdbf952', NULL, 2, 1, '2016-03-24 03:32:05', '2016-03-24 03:32:05', NULL),
(15, 0, 'asdas', NULL, 'asda@asda.com', '3c130ea5d8d2d3daca7f6808cdf0f148', NULL, 2, 1, '2016-03-24 03:37:31', '2016-03-24 03:37:31', NULL),
(16, 0, 'Heel', NULL, 'wasifhell@mailinator.com', '22d7fe8c185003c98f97e5d6ced420c7', NULL, 2, 1, '2016-03-24 03:42:43', '2016-03-24 03:42:43', NULL),
(17, 0, 'Mujahid', NULL, 'mujahid_iq@hotmail.com', '431ab62b3b32f8c12bf47b05db0581ce', NULL, 2, 1, '2016-03-24 05:13:29', '2016-03-24 05:13:29', NULL),
(18, 0, 'Umair Jaffar', NULL, 'umair.jaffar@technyxsystems.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, 2, 1, '2016-03-24 10:34:25', '2016-03-24 10:34:25', 'ba29c8ca0330313c6afa3e8f723e649a');

-- --------------------------------------------------------

--
-- Table structure for table `user_banks`
--

CREATE TABLE IF NOT EXISTS `user_banks` (
  `bank_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT '0',
  `bank_name` varchar(100) DEFAULT NULL,
  `bank_address` varchar(250) DEFAULT NULL,
  `swift_code` int(250) DEFAULT NULL,
  `account_title` varchar(250) DEFAULT NULL,
  `account_number` varchar(100) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `updated` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `user_banks`
--

INSERT INTO `user_banks` (`bank_id`, `user_id`, `bank_name`, `bank_address`, `swift_code`, `account_title`, `account_number`, `status`, `updated`, `created`) VALUES
(1, 2, 'UBL', NULL, NULL, NULL, '5001 0081', 1, '2016-03-13 15:10:37', '2016-03-13 15:10:37'),
(2, 3, 'Umair Bank Name', NULL, NULL, NULL, '00998877665544332211', 1, '2016-03-17 04:24:21', '2016-03-17 04:24:21'),
(3, 4, 'ow bank', NULL, NULL, NULL, '123123123123123123', 1, '2016-03-20 13:12:36', '2016-03-20 13:12:36'),
(4, 7, 'cvjjj', NULL, NULL, NULL, '455882223', 1, '2016-03-20 13:30:53', '2016-03-20 13:30:53'),
(5, 18, 'Test Umair Bank - Changed', NULL, NULL, NULL, '12345678901', 1, '2016-03-24 10:47:26', '2016-03-24 10:44:10'),
(6, 10, 'aasda', NULL, NULL, NULL, '123123123123123123', 1, '2016-03-25 03:07:29', '2016-03-25 03:07:29');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE IF NOT EXISTS `user_details` (
  `detail_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT '0',
  `security_question_id` int(11) DEFAULT '0',
  `security_answer` varchar(100) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `updated` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`detail_id`, `user_id`, `security_question_id`, `security_answer`, `status`, `updated`, `created`) VALUES
(1, 2, 1, 'Hen', 1, '2016-03-13 15:01:26', '2016-03-13 15:01:26'),
(2, 3, 1, 'Rabbit', 1, '2016-03-17 03:53:44', '2016-03-17 03:53:44'),
(3, 4, 1, 'asdasd', 1, '2016-03-20 11:50:50', '2016-03-20 11:50:50'),
(4, 4, 1, 'asdasd', 1, '2016-03-20 11:53:54', '2016-03-20 11:53:54'),
(5, 4, 1, 'asdasd', 1, '2016-03-20 11:53:54', '2016-03-20 11:53:54'),
(6, 4, 1, 'asdasd', 1, '2016-03-20 11:56:30', '2016-03-20 11:56:30'),
(7, 4, 1, '222', 1, '2016-03-20 11:57:24', '2016-03-20 11:57:24'),
(8, 4, 2, '222', 1, '2016-03-20 11:57:30', '2016-03-20 11:57:30'),
(9, 7, 1, 'fhhy', 1, '2016-03-20 13:30:30', '2016-03-20 13:30:30'),
(10, 7, 2, 'fgjk', 1, '2016-03-20 13:30:34', '2016-03-20 13:30:34'),
(11, 15, 2, 'ada', 1, '2016-03-24 03:37:39', '2016-03-24 03:37:39'),
(12, 18, 1, 'rabbit', 1, '2016-03-24 10:41:31', '2016-03-24 10:41:31'),
(13, 10, 2, 'Pakistan', 1, '2016-03-25 03:04:54', '2016-03-25 03:04:54');

-- --------------------------------------------------------

--
-- Table structure for table `user_merchant_info`
--

CREATE TABLE IF NOT EXISTS `user_merchant_info` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `cx_authenticate_id` varchar(255) DEFAULT NULL,
  `cx_authenticate_password` varchar(255) DEFAULT NULL,
  `cx_secret_key` varchar(255) DEFAULT NULL,
  `cx_hash` varchar(255) DEFAULT NULL,
  `cx_mode` varchar(255) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_stores`
--

CREATE TABLE IF NOT EXISTS `user_stores` (
  `store_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text,
  `address` varchar(250) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `updated` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `user_stores`
--

INSERT INTO `user_stores` (`store_id`, `user_id`, `name`, `description`, `address`, `phone`, `logo`, `status`, `updated`, `created`) VALUES
(1, 2, 'Sharff', NULL, NULL, NULL, 'http://localhost/payment2/assets/img/stores/1457881669.jpg', 1, '2016-03-13 15:07:49', '2016-03-13 15:07:49'),
(2, 3, 'Umair Store', NULL, NULL, NULL, '', 1, '2016-03-17 04:22:52', '2016-03-17 04:22:52'),
(3, 4, 'wow', NULL, NULL, NULL, '', 1, '2016-03-20 13:12:25', '2016-03-20 13:12:25'),
(4, 7, 'fhjjj', NULL, NULL, NULL, '', 1, '2016-03-20 13:30:41', '2016-03-20 13:30:41'),
(5, 9, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(6, 10, 'asdas', NULL, NULL, NULL, NULL, 1, '2016-03-25 03:06:17', NULL),
(7, 11, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(8, 12, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(9, 13, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(10, 14, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(11, 15, 'vvv', NULL, NULL, NULL, NULL, 1, '2016-03-24 03:37:52', NULL),
(12, 16, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(13, 17, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL),
(14, 18, 'Test Umair Store 991', NULL, NULL, NULL, NULL, 1, '2016-03-24 10:42:31', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`device_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_line_items`
--
ALTER TABLE `order_line_items`
  ADD PRIMARY KEY (`order_line_item_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`product_category_id`);

--
-- Indexes for table `product_media`
--
ALTER TABLE `product_media`
  ADD PRIMARY KEY (`media_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `security_questions`
--
ALTER TABLE `security_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_banks`
--
ALTER TABLE `user_banks`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`detail_id`);

--
-- Indexes for table `user_merchant_info`
--
ALTER TABLE `user_merchant_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_stores`
--
ALTER TABLE `user_stores`
  ADD PRIMARY KEY (`store_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `device_id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `order_line_items`
--
ALTER TABLE `order_line_items`
  MODIFY `order_line_item_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `product_category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `product_media`
--
ALTER TABLE `product_media`
  MODIFY `media_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `security_questions`
--
ALTER TABLE `security_questions`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `user_banks`
--
ALTER TABLE `user_banks`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `detail_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `user_merchant_info`
--
ALTER TABLE `user_merchant_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_stores`
--
ALTER TABLE `user_stores`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
